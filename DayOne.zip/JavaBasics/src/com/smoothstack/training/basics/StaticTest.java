package com.smoothstack.training.basics;

public class StaticTest {

	public static void main(String[] args) {
//		StaticExample se1 = new StaticExample();
//		se1.printInstanceCount();
//				
//		StaticExample se2 = new StaticExample();
//		se2.printInstanceCount();
//		
//		StaticExample se3 = new StaticExample();
//		se3.printInstanceCount();
		
		for(int i=1; i< 5; i++){
			System.out.println("Iteration started "+i);
			if(i==3){
//				break;
				continue;
			}
			System.out.println("do something");
			System.out.println("do something");
			System.out.println("do something");
			System.out.println("do something");
			
			
		}

	}

}
