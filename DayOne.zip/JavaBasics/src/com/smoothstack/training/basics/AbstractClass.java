package com.smoothstack.training.basics;

public abstract class AbstractClass {
	
	public abstract void abstractMethod();
	
	public void nonAbstractmethod(){
		
	}

}
