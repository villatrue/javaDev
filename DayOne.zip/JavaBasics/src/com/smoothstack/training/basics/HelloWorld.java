package com.smoothstack.training.basics;

public class HelloWorld {
	
	public HelloWorld(){
		
	}

	public static void main(String[] args) {
		System.out.println("Argument 1: "+ args[0]);
		System.out.println("Argument 2: "+ args[1]);
		System.out.println("Hello World");
	}
	
	public void testRun(){
		System.out.println("Test");
	}

}


// public - anyone

// private - only with in the class.

// protected - only with in the package.

// default