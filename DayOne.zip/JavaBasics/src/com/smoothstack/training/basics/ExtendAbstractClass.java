package com.smoothstack.training.basics;

public class ExtendAbstractClass extends AbstractClass{

	@Override
	public void abstractMethod() {
		// TODO Auto-generated method stub
		
	}

}
